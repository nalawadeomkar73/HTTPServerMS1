package test.edu.upenn.cis455.hw1;

import junit.framework.TestCase;

public class HelloWorldTest extends TestCase {
  public void testA() {
	  assertTrue(true);
  }
}
